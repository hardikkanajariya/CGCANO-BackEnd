<img src="{{url('/')}}/assets/img/logo.png" alt="Logo" {{ $attributes }} />
